package org.javaboy.filteranalysis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilteranalysisApplication {

    public static void main(String[] args) {
        SpringApplication.run(FilteranalysisApplication.class, args);
    }

}
