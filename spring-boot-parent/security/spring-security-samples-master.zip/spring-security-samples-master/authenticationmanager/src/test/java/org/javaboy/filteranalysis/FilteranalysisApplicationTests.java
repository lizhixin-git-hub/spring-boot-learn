package org.javaboy.filteranalysis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilteranalysisApplicationTests {

    @Test
    void contextLoads() {
    }

}
