package org.javaboy.voter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoterApplicationTests {

    @Test
    void contextLoads() {
    }

}
