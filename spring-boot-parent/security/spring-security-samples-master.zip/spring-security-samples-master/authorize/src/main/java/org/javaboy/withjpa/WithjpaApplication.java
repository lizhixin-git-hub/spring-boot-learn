package org.javaboy.withjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WithjpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(WithjpaApplication.class, args);
    }

}
