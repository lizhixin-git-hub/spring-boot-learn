package org.javaboy.session3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Session3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
