package org.javaboy.multiusers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiusersApplicationTests {

    @Test
    void contextLoads() {
    }

}
