package org.javaboy.multiusers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiusersApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultiusersApplication.class, args);
    }

}
