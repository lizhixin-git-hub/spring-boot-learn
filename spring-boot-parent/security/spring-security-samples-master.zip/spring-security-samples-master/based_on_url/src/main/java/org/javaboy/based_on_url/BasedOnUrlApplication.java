package org.javaboy.based_on_url;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasedOnUrlApplication {

    public static void main(String[] args) {
        SpringApplication.run(BasedOnUrlApplication.class, args);
    }

}
