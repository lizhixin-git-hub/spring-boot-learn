package org.javaboy.based_on_url;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasedOnUrlApplicationTests {

    @Test
    void contextLoads() {
    }

}
