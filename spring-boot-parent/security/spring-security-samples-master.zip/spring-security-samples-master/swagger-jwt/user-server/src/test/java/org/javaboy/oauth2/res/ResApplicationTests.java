package org.javaboy.oauth2.res;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResApplicationTests {

    @Test
    void contextLoads() {
    }

}
