package org.javaboy.stricthttpfirewall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StricthttpfirewallApplication {

    public static void main(String[] args) {
        SpringApplication.run(StricthttpfirewallApplication.class, args);
    }

}
