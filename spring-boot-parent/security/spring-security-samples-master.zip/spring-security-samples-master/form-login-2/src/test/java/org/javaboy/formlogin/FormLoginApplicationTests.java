package org.javaboy.formlogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormLoginApplicationTests {

    @Test
    void contextLoads() {
    }

}
