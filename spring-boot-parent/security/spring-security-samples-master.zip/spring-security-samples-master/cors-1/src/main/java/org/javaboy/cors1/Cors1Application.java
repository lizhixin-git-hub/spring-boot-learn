package org.javaboy.cors1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cors1Application {

    public static void main(String[] args) {
        SpringApplication.run(Cors1Application.class, args);
    }

}
