package org.javaboy.csrf1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Csrf1Application {

    public static void main(String[] args) {
        SpringApplication.run(Csrf1Application.class, args);
    }

}
